Script for launching sing-box (https://github.com/SagerNet/sing-box) on Asus routers with Merlin firmware.

I. Nuances.
1. You should be able to write configuration files for sing-box.
2. It is better to install on a flash drive with Entware. You can also install in the /jffs/ directory, but then the config.json will not work if it contains the cache_file section in the experimental section. Further, we will consider installation only on a flash drive with Entware.
3. Specifying DNS servers in the config breaks the routing rules specified in this config. It works fine for me without specifying DNS servers in the config - the DNS configured in the router is used.
4. You can experiment with the script and configs. If you achieve noteworthy success, for example, overcome the nuances mentioned above, please share them with as.

II. Unpacking the archive with the script.
1. If you are reading this readme, then you have already unpacked the top layer of the archive and you have this readme.txt file and another archive sing-box-script.tar.gz. Place the sing-box-script.tar.gz archive in the /mnt/entware/entware/root/ directory (for example, using WinSCP), or wherever your /root/ directory is on the flash drive with Entware.
If your /root/ directory on the flash drive with Entware is located on a different path, then you need to change the path to the appropriate one in all subsequent commands. Also, while performing the items in the next section III, change the paths for cache_file and external_ui in the config.json and for SING_BOX_PATH and CONFIG_PATH in the sing-box.sh script. 2. Run the command in the router console to unpack the sing-box-script.tar.gz archive to the /mnt/entware/entware/root/ directory on the flash drive with Entware:
tar -xvpzf /mnt/entware/entware/root/sing-box-script.tar.gz -C /mnt/entware/entware/root/

III. Script and config configuration.
1. After completing the previous section, the /sing-box/ directory with the necessary files inside appeared in your /root/ directory on the flash drive with Entware. They already have the necessary rights. Open the sing-box.sh script file with a text editor in the router console, for example nano, or the same WinSCP and substitute your values ​​​​in the variables where necessary. There are hints there.
2. In the config.json file, also make the necessary changes. It uses my personal ruleset, which is automatically downloaded from my GitHub page (https://github.com/Dr4tez/my_domains), it may not have the blocked domains you need, and the traffic is sent to direct by default according to the config.json settings.
By default, sing-box version 1.10.0-alpha.18-linux-arm64 is used. If you want a different version, you can replace the sing-box file in the sing-box folder with the one you need, just do not forget to give it execution rights and, if necessary, change the config according to the Migration section (https://sing-box.sagernet.org/migration/) in the sing-box documentation.

IV. Script control commands.
1.In the router console, to start sing-box, run:
/mnt/entware/entware/root/sing-box/sing-box.sh start
To stop sing-box, run:
/mnt/entware/entware/root/sing-box/sing-box.sh stop
To restart sing-box, run:
/mnt/entware/entware/root/sing-box/sing-box.sh restart
2. After executing the command
/mnt/entware/entware/root/sing-box/sing-box.sh start
or
/mnt/entware/entware/root/sing-box/sing-box.sh restart
the script works correctly until you close the console. Therefore, after starting or restarting the script and closing the console, reboot the router, then the script will start automatically after rebooting the router and will work correctly without the console.
3. If you want to completely stop the script and do not want the script to start automatically when you reboot the router, then execute the command in the console
/mnt/entware/entware/root/sing-box/sing-box.sh stop
After this command, you do not need to reboot the router.

V. Complete removal of the script.
In the router console, execute the command:
/mnt/entware/entware/root/sing-box/sing-box.sh stop
After that, delete the directory /mnt/entware/entware/root/sing-box using the command:
rm -r /mnt/entware/entware/root/sing-box